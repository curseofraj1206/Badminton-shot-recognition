# Badmintion-Shot-Recognition
This is the project based on Playing the badmintion this method is to Recognition the Shot by a Video clip
