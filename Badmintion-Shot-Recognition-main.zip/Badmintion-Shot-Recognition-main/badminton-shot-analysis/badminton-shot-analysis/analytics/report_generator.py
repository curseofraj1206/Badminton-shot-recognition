from collections import Counter
import numpy as np
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas


def generate_report(shots, timeline, total_frames, video_name, labels, rallies):

    pdf_file = "match_report.pdf"

    c = canvas.Canvas(pdf_file, pagesize=letter)

    width, height = letter
    y = height - 40

    def write(text=""):
        nonlocal y
        c.drawString(40, y, text)
        y -= 15

        if y < 40:
            c.showPage()
            y = height - 40


    write("=================================================")
    write("           BADMINTON SHOT ANALYSIS REPORT")
    write("=================================================")

    write("")
    write(f"Video File        : {video_name}")
    write("Model             : LSTM Pose-Based Shot Classifier")
    write(f"Detected Classes  : {', '.join(labels)}")
    write(f"Total Frames      : {total_frames:,}")
    write(f"Total Shots Found : {len(shots)}")

    write("")
    write("-------------------------------------------------")
    write("RALLY STATISTICS")
    write("-------------------------------------------------")

    total_rallies = len(rallies)

    rally_lengths = []

    for rally in rallies:

        start = rally[0][0]
        end = rally[-1][0]

        rally_shots = [
            s for s in shots
            if start <= int(s[0]*30) <= end
        ]

        rally_lengths.append(len(rally_shots))

    if rally_lengths:
        avg_len = sum(rally_lengths) / len(rally_lengths)
        longest = max(rally_lengths)
    else:
        avg_len = 0
        longest = 0

    write(f"Total Rallies        : {total_rallies}")
    write(f"Average Rally Length : {avg_len:.1f} shots")
    write(f"Longest Rally        : {longest} shots")

    write("")
    write("-------------------------------------------------")
    write("SHOT DISTRIBUTION")
    write("-------------------------------------------------")

    shot_labels = [s[1] for s in shots]
    counts = Counter(shot_labels)

    total = len(shots)

    for label in labels:

        c_val = counts.get(label, 0)
        pct = (c_val / total) * 100 if total else 0

        write(f"{label:6} : {c_val}   ({pct:.1f}%)")

    most_common = counts.most_common(1)[0][0] if total else "None"

    write("")
    write(f"Most Frequent Shot : {most_common}")

    write("")
    write("-------------------------------------------------")
    write("SHOT TIMELINE")
    write("-------------------------------------------------")

    for t, shot, conf in shots:

        m = int(t // 60)
        s = int(t % 60)

        write(f"{m:02d}:{s:02d}  {shot}  ({conf:.2f})")

    write("")
    write("-------------------------------------------------")
    write("GAMEPLAY INSIGHTS")
    write("-------------------------------------------------")

    smash_freq = counts.get("Smash", 0) / total if total else 0
    net_freq = counts.get("Net", 0) / total if total else 0
    lift_freq = counts.get("Lift", 0) / total if total else 0

    if smash_freq > 0.35:
        style = "Aggressive"
    elif smash_freq < 0.15:
        style = "Defensive"
    else:
        style = "Balanced"

    if net_freq > 0.25:
        net_control = "High"
    elif net_freq > 0.10:
        net_control = "Moderate"
    else:
        net_control = "Low"

    if lift_freq > 0.25:
        defense = "High"
    elif lift_freq > 0.10:
        defense = "Moderate"
    else:
        defense = "Low"

    smash_level = "High" if smash_freq > 0.3 else "Moderate"

    write(f"Playing Style      : {style}")
    write(f"Smash Frequency    : {smash_level}")
    write(f"Net Control        : {net_control}")
    write(f"Defensive Shots    : {defense}")

    write("")
    write("-------------------------------------------------")
    write("MODEL CONFIDENCE SUMMARY")
    write("-------------------------------------------------")

    confidences = [t[2] for t in timeline]

    if confidences:

        avg_conf = np.mean(confidences)

        max_conf = np.max(confidences)
        min_conf = np.min(confidences)

        max_index = np.argmax(confidences)
        min_index = np.argmin(confidences)

        write("")
        write(f"Average Prediction Confidence : {avg_conf*100:.1f}%")

        write("")
        write("Highest Confidence Shot")
        write(f"Shot Type : {timeline[max_index][1]}")
        write(f"Confidence : {max_conf*100:.1f}%")

        write("")
        write("Lowest Confidence Shot")
        write(f"Shot Type : {timeline[min_index][1]}")
        write(f"Confidence : {min_conf*100:.1f}%")

    write("")
    write("=================================================")
    write("              END OF ANALYSIS REPORT")
    write("=================================================")

    c.save()

    print("PDF report saved as match_report.pdf")