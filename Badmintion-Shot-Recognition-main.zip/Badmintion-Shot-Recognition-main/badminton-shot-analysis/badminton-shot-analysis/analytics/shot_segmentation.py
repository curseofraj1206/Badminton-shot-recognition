def segment_shots(smoothed_timeline, min_gap=1.2):
    """
    Convert smoothed frame predictions into shot events.
    min_gap = minimum seconds between two shots
    """

    shots = []
    last_label = None
    last_time = -999

    for time_sec, label, conf in smoothed_timeline:

        if label != last_label and (time_sec - last_time) > min_gap:

            shots.append((time_sec, label, conf))

            last_label = label
            last_time = time_sec

    return shots