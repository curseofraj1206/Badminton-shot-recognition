def assign_shots_to_rallies(shots, rallies, fps):

    rally_shots = []

    for rally in rallies:

        start = rally[0][0] / fps
        end = rally[-1][0] / fps

        rally_list = []

        for t, label, conf in shots:

            if start <= t <= end:
                rally_list.append((t, label))

        rally_shots.append(rally_list)

    return rally_shots