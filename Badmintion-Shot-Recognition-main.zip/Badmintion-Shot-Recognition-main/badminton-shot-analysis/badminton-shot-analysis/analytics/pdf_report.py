from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas


def create_pdf_report(report_text):

    file_name = "match_report.pdf"

    c = canvas.Canvas(file_name, pagesize=letter)

    width, height = letter

    y = height - 40

    lines = report_text.split("\n")

    for line in lines:

        c.drawString(40, y, line)

        y -= 15

        if y < 40:
            c.showPage()
            y = height - 40

    c.save()

    print("PDF report saved as match_report.pdf")