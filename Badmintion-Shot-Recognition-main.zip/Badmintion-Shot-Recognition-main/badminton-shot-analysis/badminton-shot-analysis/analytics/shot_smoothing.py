def smooth_predictions(timeline, window_size=7):
    """
    Majority smoothing over predictions.
    """
    smoothed = []

    for i in range(len(timeline)):

        start = max(0, i - window_size//2)
        end = min(len(timeline), i + window_size//2)

        window = timeline[start:end]

        labels = [x[1] for x in window]

        majority = max(set(labels), key=labels.count)

        smoothed.append((timeline[i][0], majority, timeline[i][2]))

    return smoothed