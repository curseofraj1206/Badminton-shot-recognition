import numpy as np


def segment_rallies(shuttle_positions, max_gap=35, max_jump=200, min_length=40):

    rallies = []

    current_rally = []

    prev_frame = None
    prev_point = None

    for frame, x, y in shuttle_positions:

        point = np.array([x, y])

        if prev_frame is None:

            current_rally.append((frame, x, y))

        else:

            frame_gap = frame - prev_frame

            jump = np.linalg.norm(point - prev_point)

            if frame_gap > max_gap or jump > max_jump:

                if len(current_rally) > min_length:
                    rallies.append(current_rally)

                current_rally = []

            current_rally.append((frame, x, y))

        prev_frame = frame
        prev_point = point

    if len(current_rally) > min_length:
        rallies.append(current_rally)

    return rallies